package pooltest;

import config.DatabaseConnectionPool;
import java.sql.Connection;

import java.sql.SQLException;

public class PoolTest {

  public static void main(String[] args) {
        System.out.println("🔄 Probando conexiones desde el pool...");

        // Intentar obtener y cerrar múltiples conexiones
        for (int i = 1; i <= 5; i++) {
            try (Connection conn = DatabaseConnectionPool.getConnection()) {
                if (conn != null) {
                    System.out.println("✅ Conexión #" + i + " establecida correctamente.");
                } else {
                    System.out.println("❌ Conexión #" + i + " fallida.");
                }
            } catch (SQLException e) {
                System.err.println("⚠️ Error en la conexión #" + i + ": " + e.getMessage());
                e.printStackTrace();
            }
        }

        System.out.println("🚀 Prueba finalizada.");
    }

}
